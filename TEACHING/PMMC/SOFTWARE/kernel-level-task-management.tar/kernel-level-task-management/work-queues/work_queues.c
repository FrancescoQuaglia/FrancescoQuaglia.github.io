#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/version.h>
#include <linux/workqueue.h>


// This gives access to read_cr0() and write_cr0()
#if LINUX_VERSION_CODE > KERNEL_VERSION(3,3,0)
    #include <asm/switch_to.h>
#else
    #include <asm/system.h>
#endif
#ifndef X86_CR0_WP
#define X86_CR0_WP 0x00010000
#endif


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia <quaglia@dis.uniroma1.it>");
MODULE_DESCRIPTION("basic example usage of kernel work queues");

#define MODNAME "PUT WORK"


int restore[2] = {[0 ... 1] -1}; //can hack up to 2 system call table entries

/* please take the two values below from the system map */
unsigned long sys_call_table = 0xffffffff81800300;
unsigned long sys_ni_syscall = 0xffffffff8107e700;

static int reschedule = 0;// this can be configured at run time via the sys file system - not 0 meas continuous work reschedule
module_param(reschedule,int,0666);

static int core = 0;// this can be configured at run time via the sys file system - it is the id of the target core for the reschedule (if active)
module_param(core,int,0666);

static int can_unload = 1;// this can be configured at run time via the sys file system - you use it at your own pace
module_param(can_unload,int,0666);


struct work_struct the_work;


void audit(void* data){
	
	printk("%s: this print comes from kworker thread %d - running on CPU-core %d\n",MODNAME,current->pid,smp_processor_id());
	if(reschedule){
		__INIT_WORK(&the_work,audit,NULL);
		schedule_work_on(core,&the_work);
	}

}



asmlinkage long sys_put_work(void){
	
	bool outcome1, outcome2;

	__INIT_WORK(&the_work,audit,NULL);

	outcome1 = schedule_work(&the_work);

	outcome2 = schedule_work(&the_work);//this should fail - the static buffer holding the work should be found busy

	printk("%s: outcome 1 is: %d\n",MODNAME,outcome1);
	printk("%s: outcome 2 is: %d\n",MODNAME,outcome2);

	printk("%s: sys_put_work called from thread %d\n",MODNAME,current->pid);

	return 0;
}

int init_module(void) {

	unsigned long * p = (unsigned long *) sys_call_table;
	int i,j;
	int ret;

	unsigned long cr0;

	printk("%s: initializing\n",MODNAME);


	j = -1;
	for (i=0; i<256; i++){
		if (p[i] == sys_ni_syscall){
			printk("%s: table entry %d keeps address %p\n",MODNAME,i,(void*)p[i]);
			j++;
			restore[j] = i;
			if (j == 0) break;
		}
	}

	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = (unsigned long)sys_put_work;
	write_cr0(cr0);

	printk("%s: new system-call sys_put_work installed on sys-call table entry %d\n",MODNAME,restore[0]);

	ret = 0;

	return ret;


}


void cleanup_module(void) {

	unsigned long * p = (unsigned long*) sys_call_table;
	unsigned long cr0;
        	
	printk("%s: shutting down\n",MODNAME);
	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = sys_ni_syscall;
	write_cr0(cr0);
	printk("%s: sys-call table restored to its original content\n",MODNAME);
	
}

