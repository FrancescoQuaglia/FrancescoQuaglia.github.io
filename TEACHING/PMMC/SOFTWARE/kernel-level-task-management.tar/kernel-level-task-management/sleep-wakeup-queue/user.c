
/**************************************************************************
   this user program allows you to access the sys_log_message 
   and sys_get_message system calls added to the kernel via the
   sys-call-table-hacker module
**************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>


#define AUDIT if(1)


int sleep_or_awake(long int x){
	return syscall(x);
}

void* do_job(void * arg){
	sleep_or_awake((long int)arg);
	return NULL;
}

int main(int argc, char** argv){
	
	long int num_threads, arg;	
	pthread_t tid;
	int i;

	if(argc < 3){
		printf("usage: prog num-spawns sycall-num\n");
		return;
	}
	
	
	num_threads = strtol(argv[1],NULL,10);
	arg = strtol(argv[2],NULL,10);
	

	for (i=0; i<num_threads; i++){
		pthread_create(&tid,NULL,do_job,(void*)arg);
	}

	pause();

}
