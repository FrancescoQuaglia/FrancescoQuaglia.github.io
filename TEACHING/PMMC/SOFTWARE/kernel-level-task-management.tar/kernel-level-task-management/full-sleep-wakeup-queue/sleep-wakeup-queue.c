#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/version.h>
#include <linux/wait.h>
#include <linux/spinlock.h>

// This gives access to read_cr0() and write_cr0()
#if LINUX_VERSION_CODE > KERNEL_VERSION(3,3,0)
    #include <asm/switch_to.h>
#else
    #include <asm/system.h>
#endif
#ifndef X86_CR0_WP
#define X86_CR0_WP 0x00010000
#endif


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia <quaglia@dis.uniroma1.it>");
MODULE_DESCRIPTION("this module implements a sleep/wakeup FIFO queue");

//NOTE: module locking is not explicit - you should implement explicit locking by your own if needed 

#define MODNAME "SLEEP/WAKEUP QUEUE"


#define NO (0)
#define YES (NO+1)
#define AUDIT if(1)

int restore[2] = {[0 ... 1] -1};//can hack up to 2 system call table entries - one for the sleep service one for the awake service

/* please take the two values below from the system map */
unsigned long sys_call_table = 0xffffffff81800300;
unsigned long sys_ni_syscall = 0xffffffff8107e700;


static int enable_sleep = 1;// this can be configured at run time via the sys file system - 1 meas any sleeping thread is freezed
module_param(enable_sleep,int,0666);

atomic_t count ;//this is used to audit how many threads are still sleeping onto the sleep/wakeup queue
module_param(count,long,0666);

typedef struct _elem{
	struct task_struct *task;	
	int pid;
	int awake;
	int already_hit;
	struct _elem * next;
} elem;

elem head = {NULL,-1,-1,-1,NULL};
elem *list = &head;
spinlock_t queue_lock; 



asmlinkage long sys_goto_sleep(void){
	

	volatile elem me;
	elem *aux;
	DECLARE_WAIT_QUEUE_HEAD(the_queue);//here we use a private queue - wakeup is selective via wake_up_process

	me.next = NULL;
	me.task = current;
	me.pid  = current->pid;
	me.awake = NO;
	me.already_hit = NO;

	AUDIT
	printk("%s: sys_goto_sleep on strong fifo sleep/wakeup queue called from thread %d\n",MODNAME,current->pid);


	if(!enable_sleep){
		printk("%s: sys_goto_sleep - sleeping not currently enabled\n",MODNAME);
		return -1;
	}

	spin_lock(&queue_lock);
	aux = list;
	if(aux == NULL){
		spin_unlock(&queue_lock);
		printk("%s: malformed sleep-wakeup-queue - service damaged\n",MODNAME);
		return -1;
	}

	for(;aux;){//put my record at the tail
		if(aux->next == NULL){
			aux->next = &me;			
			goto sleep;
		}
		aux = aux->next;
	}	

sleep:

	spin_unlock(&queue_lock);

	atomic_inc(&count);//a new sleeper 

	AUDIT
	printk("%s: thread %d actually going to sleep\n",MODNAME,current->pid);
		
	wait_event_interruptible(the_queue, me.awake == YES);
	
	spin_lock(&queue_lock);

	aux = list;
	if(aux == NULL){
		spin_unlock(&queue_lock);
		printk("%s: malformed sleep-wakeup-queue upon wakeup - service damaged\n",MODNAME);
		return -1;
	}

	for(;aux;){//find and remove my record
		if(aux->next != NULL){
			if(aux->next->pid == current->pid){
				aux->next = me.next;			
				break;
			}
		}
		aux = aux->next;
	}	

	spin_unlock(&queue_lock);

	AUDIT
	printk("%s: thread %d exiting sleep for a wakeup or signal\n",MODNAME, current->pid);

	atomic_dec(&count);//finally awaken

	if(me.awake == NO){
		AUDIT
		printk("%s: thread %d exiting sleep for signal\n",MODNAME, current->pid);
		return -EINTR;
	}


	return 0;

}

asmlinkage long sys_awake(void){
	
	struct task_struct *the_task;
	int its_pid = -1;
	elem *aux;


	printk("%s: sys_awake called from thread %d\n",MODNAME,current->pid);
	
	aux = list;

	spin_lock(&queue_lock);

	if(aux == NULL){
		spin_unlock(&queue_lock);
		printk("%s: malformed sleep-wakeup-queue\n",MODNAME);
		return -1;
	}

	while(aux->next){
		if(aux->next->already_hit == NO){
			the_task = aux->next->task;
			aux->next->awake = YES;
			aux->next->already_hit = YES;
			its_pid = aux->next->pid;
			wake_up_process(the_task);
			goto awaken;
		}
		aux = aux->next;
	}	
	
	spin_unlock(&queue_lock);
	
	return 0;

awaken:
	spin_unlock(&queue_lock);

	AUDIT
	printk("%s: called the awake of thread %d\n",MODNAME,its_pid);

	return its_pid;

}

int init_module(void) {

	unsigned long * p = (unsigned long *) sys_call_table;
	int i,j;
	int ret;

	unsigned long cr0;

	printk("%s: initializing\n",MODNAME);

	spin_lock_init(&queue_lock);


	j = -1;
	for (i=0; i<256; i++){
		if (p[i] == sys_ni_syscall){
			printk("%s: table entry %d keeps address %p\n",MODNAME,i,(void*)p[i]);
			j++;
			restore[j] = i;
			if (j == 1) break;
		}
	}

	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = (unsigned long)sys_goto_sleep;
	p[restore[1]] = (unsigned long)sys_awake;
	write_cr0(cr0);

	printk("%s: new system-call sys_goto_sleep installed on sys-call table entry %d\n",MODNAME,restore[0]);
	printk("%s: new system-call sys_awake_pid installed on sys-call table entry %d\n",MODNAME,restore[1]);

	ret = 0;

	return ret;


}


void cleanup_module(void) {

	unsigned long * p = (unsigned long*) sys_call_table;
	unsigned long cr0;
        	
	printk("%s: shutting down\n",MODNAME);
	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = sys_ni_syscall;
	p[restore[1]] = sys_ni_syscall;
	write_cr0(cr0);
	printk("%s: sys-call table restored to its original content\n",MODNAME);
	
}

