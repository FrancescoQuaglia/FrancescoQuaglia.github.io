#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/version.h>
#include <linux/wait.h>

// This gives access to read_cr0() and write_cr0()
#if LINUX_VERSION_CODE > KERNEL_VERSION(3,3,0)
    #include <asm/switch_to.h>
#else
    #include <asm/system.h>
#endif
#ifndef X86_CR0_WP
#define X86_CR0_WP 0x00010000
#endif


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia <quaglia@dis.uniroma1.it>");
MODULE_DESCRIPTION("basic example usage of wait event queues");

#define MODNAME "SLEEP/WAKEUP"

DECLARE_WAIT_QUEUE_HEAD(the_queue);


int restore[2] = {[0 ... 1] -1};//can hack up to 2 system call table entries

/* please take the two values below from the system map */
unsigned long sys_call_table = 0xffffffff81800300;
unsigned long sys_ni_syscall = 0xffffffff8107e700;


static int enable_sleep = 1;// this can be configured at run time via the sys file system - 1 meas any sleeping thread is freezed
module_param(enable_sleep,int,0666);

int flag;

asmlinkage long sys_goto_sleep(void){
	

	printk("%s: sys_goto_sleep called from thread %d\n",MODNAME,current->pid);

	if(enable_sleep){
		
		wait_event_interruptible(the_queue,flag != 0);
		flag = 0;

	}
	else{
		printk("%s: sys_goto_sleep - sleeping not currently enabled\n");
		return -1;

	}

	return 0;
}

asmlinkage long sys_awake_all(void){
	

	printk("%s: sys_awake_all called from thread %d\n",MODNAME,current->pid);

	flag = 1;
	wake_up_interruptible(&the_queue);

	return 0;
}
int init_module(void) {

	unsigned long * p = (unsigned long *) sys_call_table;
	int i,j;
	int ret;

	unsigned long cr0;

	printk("%s: initializing\n",MODNAME);


	j = -1;
	for (i=0; i<256; i++){
		if (p[i] == sys_ni_syscall){
			printk("%s: table entry %d keeps address %p\n",MODNAME,i,(void*)p[i]);
			j++;
			restore[j] = i;
			if (j == 1) break;
		}
	}

	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = (unsigned long)sys_goto_sleep;
	p[restore[1]] = (unsigned long)sys_awake_all;
	write_cr0(cr0);

	printk("%s: new system-call sys_goto_sleep installed on sys-call table entry %d\n",MODNAME,restore[0]);
	printk("%s: new system-call sys_awake_all installed on sys-call table entry %d\n",MODNAME,restore[1]);

	ret = 0;

	return ret;


}


void cleanup_module(void) {

	unsigned long * p = (unsigned long*) sys_call_table;
	unsigned long cr0;
        	
	printk("%s: shutting down\n",MODNAME);
	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = sys_ni_syscall;
	p[restore[1]] = sys_ni_syscall;
	write_cr0(cr0);
	printk("%s: sys-call table restored to its original content\n",MODNAME);
	
}

