#include <stdlib.h>
#include <stdio.h>

_start(){
	asm volatile("int $0xf5":::);
	exit(0);
}

