#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char buffer[4096];

int main(int argc, char** argv){
	
	int sys_call_num, arg;
	
	if(argc < 2){
                printf("usage: prog syscall-num [syscall-param]\n");
                return;
        }
        
        
        sys_call_num = strtol(argv[1],NULL,10);

        if (argv[2]){
		syscall(sys_call_num,argv[2],strlen(argv[2]));
		return 0;
        }
	
	buffer[0] = '\0';
	
	syscall(sys_call_num,buffer);
	
	printf("got message: %s\n",buffer);

	return 0;
}
	
