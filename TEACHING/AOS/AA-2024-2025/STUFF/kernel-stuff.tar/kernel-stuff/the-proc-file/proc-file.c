#define EXPORT_SYMTAB
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/pid.h>          /* For pid types */
#include <linux/tty.h>          /* For the tty declarations */
#include <linux/version.h>      /* For LINUX_VERSION_CODE */
#include <linux/signal_types.h>
#include <linux/syscalls.h>
#include <asm/uaccess.h>



void create_new_proc_entry(void) ;

struct proc_dir_entry * my_entry;

char msg[4096]   __aligned(4096) = "The name Francesco is the secret\n";
int len;

unsigned long address = 0x0;
module_param(address, ulong, 0660);


ssize_t read_proc(struct file *filp,char *buf, size_t count, loff_t *offp ) {

	int ret;
	int temp = len;

	temp = count;

	if (temp > len) temp = len;

	ret = copy_to_user(buf, msg, temp);//the destination buffer is still user land

	*offp += (temp - ret); 
   
	return temp - ret;
}

struct file_operations proc_fops = {
	owner: THIS_MODULE,
	read: read_proc
};

void create_new_proc_entry() {

	my_entry = proc_create("the-secret",0,NULL,&proc_fops);
	len=strlen(msg);
	address = (ulong)msg;
	printk("The address of the secret is 0x%px\n",(void*)address);
}


int proc_init (void) {

 create_new_proc_entry();
 return 0;

}

void proc_cleanup(void) {

 remove_proc_entry("the-secret",NULL);

}

MODULE_LICENSE("GPL"); 
module_init(proc_init);
module_exit(proc_cleanup);
