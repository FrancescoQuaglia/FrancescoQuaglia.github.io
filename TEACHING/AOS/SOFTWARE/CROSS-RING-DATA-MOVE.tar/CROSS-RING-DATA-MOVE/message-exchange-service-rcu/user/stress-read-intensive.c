#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define TRIES 1000000
#define NUM_READERS 3

#ifdef FAULT
char *buffer = NULL;
#else
#define BUFF_SIZE 4096
char buffer[BUFF_SIZE];
#endif

char * the_message = "Hello world";

int main(int argc, char** argv){
	
	int post_sys_call, get_sys_call;
	int ret;
	int pid;
	int i, write = 1;
	
	 if(argc < 3){
                printf("usage: prog post-syscall-num get-syscall-num\n");
                return EXIT_FAILURE;
       	 }
        
        
       	post_sys_call = strtol(argv[1],NULL,10);
       	get_sys_call = strtol(argv[2],NULL,10);


	pid = getpid();
	for (i = 0; i < NUM_READERS; i++){
		if(!fork()) break;
	}
	if (pid != getpid()) write = 0;;

	for(i=0;i<TRIES;i++){
		if(write){
			sprintf(buffer,"(pid %d) %s %d",pid,the_message,i);
			syscall(post_sys_call,buffer,strlen(buffer));
		}
	 	ret = syscall(get_sys_call,buffer,BUFF_SIZE);
		if (ret == -1) return  EXIT_FAILURE;
		if (ret == 0){
		       	printf("no message delivered\n");
       		      	return  EXIT_FAILURE;
		}
		buffer[ret] = '\0';
	//	printf("got message: %s\n",buffer);

	}

	return 0;
}
	
