/* 
* This is free software; 
* You can redistribute it and/or modify this file under the
* terms of the GNU General Public License as published by the Free Software
* Foundation; either version 3 of the License, or (at your option) any later
* version.
* 
* This file is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License along with
* this file; if not, write to the Free Software Foundation, Inc.,
* 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
* 
* @brief This is the source file for a didactical  Linux Kernel Module which implements
*	 a kernel level message exchange service with no intermediate buffering.
* @author Francesco Quaglia
*
* @date April 26, 2018
*/
#define EXPORT_SYMTAB
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/errno.h>
#include <linux/device.h>
#include <linux/kprobes.h>
#include <linux/mutex.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/string.h>
#include <linux/vmalloc.h>
#include <asm/page.h>
#include <asm/cacheflush.h>
#include <asm/apic.h>
#include <linux/syscalls.h>
#include <linux/delay.h>

// This gives access to read_cr0() and write_cr0()
#if LINUX_VERSION_CODE > KERNEL_VERSION(3,3,0)
    #include <asm/switch_to.h>
#else
    #include <asm/system.h>
#endif
#ifndef X86_CR0_WP
#define X86_CR0_WP 0x00010000
#endif


#define AUDIT if(0)

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia <francesco.quaglia@uniroma2.it>");
MODULE_DESCRIPTION("message exchange service via two system calls installed on available ni_sys_call entries of the syscall table");

#define MODNAME "MESSAGE EXCHANGE SERVICE"

int restore[2] = {[0 ... 1] -1};

unsigned long sys_call_table;// position of the syscall table - to be discovered at startup
unsigned long sys_ni_syscall_a;// position of the sys_ni_syscall code - to be discovred at startup

#define MAX_MSG_SIZE 4096
char  kernel_buff[MAX_MSG_SIZE];
size_t valid = 0;

static DEFINE_MUTEX(log_get_mutex);


long _log_message(char* mex, size_t size){
        
        unsigned long ret;
        void* addr;

        AUDIT
        printk("%s: sys_log_message has been called with params  %p - %d\n",MODNAME,mex,(int)size);

        if(size >= (MAX_MSG_SIZE -1)) goto bad_size;//leave 1 byte for string terminator

        addr = (void*)get_zeroed_page(GFP_KERNEL);

	if (addr == NULL) return -1;

        ret = copy_from_user((char*)addr,(char*)mex,size);//returns the number of bytes NOT copied

        mutex_lock(&log_get_mutex);
        memcpy((char*)kernel_buff,(char*)addr,size-ret);
        kernel_buff[size - ret] = '\0';

        AUDIT
        printk("%s: kernel buffer updated content is: %s\n",MODNAME,kernel_buff);

        valid = size - ret;
        mutex_unlock(&log_get_mutex);

        free_pages((unsigned long)addr,0);

        return size - ret;

bad_size:

        return -1;
}

long _get_message(char* mex, size_t size){

        unsigned long ret;
        void* addr;
        
        AUDIT
        printk("%s: sys_get_message has been called with params  %p - %d\n",MODNAME,mex,(int)size);

        if(size > MAX_MSG_SIZE) goto bad_size;

        addr = (void*)get_zeroed_page(GFP_KERNEL);

	if (addr == NULL) return -1;

        mutex_lock(&log_get_mutex);
        if (size > valid) size = valid; 
        memcpy((char*)addr,(char*)kernel_buff,size);
        mutex_unlock(&log_get_mutex);

        ret = copy_to_user((char*)mex,(char*)addr,size);
        free_pages((unsigned long)addr,0);
        
        AUDIT
        printk("%s: sys_get_message copy to user returned %d\n",MODNAME,(int)ret);
        return size - ret;

bad_size:

        return -1;
}


static	DEFINE_MUTEX(rcu_mutex);
typedef struct _rcu_list{
        int epoch;
        long standing[2];
        char* kernel_buffer;//last bytes used for counting valid bytes
} _rcu_message;

_rcu_message *rcu_message;

int rcu_message_init(void){

	rcu_message = kzalloc(sizeof(_rcu_message),GFP_KERNEL);
	if (rcu_message == NULL) return 0;
	rcu_message->kernel_buffer = get_zeroed_page(GFP_KERNEL);
	if (rcu_message->kernel_buffer == NULL) return 0;
	*((size_t*)(rcu_message->kernel_buffer+MAX_MSG_SIZE-sizeof(size_t))) = 0;
	return 1;
}

int rcu_wait_cycles = 0;
module_param(rcu_wait_cycles,int,0660);

long _log_message_rcu(char* mex, size_t size){
        
        unsigned long ret;
        char* addr;
	int old_epoch;
	void* old_buffer;

        AUDIT
        printk("%s: sys_log_message RCU has been called with params  %p - %d\n",MODNAME,mex,(int)size);

        if(size >= (MAX_MSG_SIZE -1)) goto bad_size;//leave 1 byte for string terminator

        addr = (void*)get_zeroed_page(GFP_KERNEL);

	if (addr == NULL) return -1;

        ret = copy_from_user((char*)addr,(char*)mex,size);//returns the number of bytes NOT copied
        addr[size - ret] = '\0';
	*((size_t*)(addr+MAX_MSG_SIZE-sizeof(size_t))) = size - ret;

        mutex_lock(&rcu_mutex);
	old_epoch = rcu_message->epoch;
	rcu_message->epoch = (rcu_message->epoch + 1)%2; 
	asm("mfence"::);
	old_buffer = rcu_message->kernel_buffer;
	asm("mfence"::);
	rcu_message->kernel_buffer = addr;
	asm("mfence"::);

	while(rcu_message->standing[old_epoch] > 0 ){
        __sync_fetch_and_add(&rcu_wait_cycles,1);
	 usleep_range(5,10);
	}


        AUDIT
        printk("%s: kernel buffer updated content is: %s\n",MODNAME,rcu_message->kernel_buffer);

        mutex_unlock(&rcu_mutex);

        free_pages((unsigned long)old_buffer,0);

        return size - ret;

bad_size:

        return -1;
}

long _get_message_rcu(char* mex, size_t size){

	int my_epoch;
        unsigned long ret;
        void* addr;
	size_t *valid;
        

        AUDIT
        printk("%s: sys_get_message RCU has been called with params  %p - %d\n",MODNAME,mex,(int)size);

        if(size > MAX_MSG_SIZE) goto bad_size;

	my_epoch = rcu_message->epoch;
        __sync_fetch_and_add(&rcu_message->standing[my_epoch],1);

	addr = rcu_message->kernel_buffer;
	valid = addr+MAX_MSG_SIZE-sizeof(size_t);
        if (size > *valid) size = *valid; 

        ret = copy_to_user((char*)mex,(char*)addr,size);

	__sync_fetch_and_add(&rcu_message->standing[my_epoch],-1);
        
        AUDIT
        printk("%s: sys_get_message copy to user returned %d\n",MODNAME,(int)ret);

        return size - ret;

bad_size:

        return -1;
}




int rcu = 1;
module_param(rcu,int,0660);

unsigned long log_message[2] = {_log_message,_log_message_rcu};
unsigned long get_message[2] = {_get_message,_get_message_rcu};

asmlinkage long sys_log_message(char* mex, size_t size){
	long (*f)(char*,size_t);
	 f = log_message[rcu];
	 return f(mex,size);
}
asmlinkage long sys_get_message(char* mex, size_t size){
	long (*f)(char*,size_t);
	 f = get_message[rcu];
	 return f(mex,size);
}

unsigned long *get_syscall_table(void) {

        unsigned long *syscall_table;
        unsigned long int i;

        for (i = (unsigned long int)sys_close; i < ULONG_MAX; i += sizeof(void *)) {
                syscall_table = (unsigned long *)i;

                if (syscall_table[__NR_close] == (unsigned long)sys_close)
                        return syscall_table;
        }
        return NULL;
}

int init_module(void) {

	unsigned long * p ; //= (unsigned long *) sys_call_table;
	int i,j;
	int ret;

	unsigned long cr0;

	unsigned long target;

        printk("%s: initializing\n",MODNAME);
        
	if(!rcu_message_init()) return -1;

        p = sys_call_table = get_syscall_table();

        if(p == NULL){

                printk("%s: could not locate syscall table position\n",MODNAME);
                return -1;

        }


        for(i=0;i<256;i++){
                for(j=i+1;j<256;j++){
                        if(p[i] == p[j]){
                                target = p[i];
                                goto found;
                        }
                }

        }

	return -1;

found:

	sys_ni_syscall_a = target;

	j = -1;
	for (i=0; i<256; i++){
		if (p[i] == sys_ni_syscall_a){
			printk("%s: table entry %d keeps address %p\n",MODNAME,i,(void*)p[i]);
			j++;
			restore[j] = i;
			if (j == 1) break;
		}
	}

	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = (unsigned long)sys_log_message;
	p[restore[1]] = (unsigned long)sys_get_message;
	write_cr0(cr0);

	printk("%s: new system-call sys_log_message installed on sys-call table entry %d\n",MODNAME,restore[0]);
	printk("%s: new system-call sys_get_message installed on sys-call table entry %d\n",MODNAME,restore[1]);

	ret = 0;

	return ret;
}


void cleanup_module(void) {

	unsigned long * p = (unsigned long*) sys_call_table;
	unsigned long cr0;
        	
	printk("%s: shutting down\n",MODNAME);
	cr0 = read_cr0();
        write_cr0(cr0 & ~X86_CR0_WP);
	p[restore[0]] = sys_ni_syscall_a;
	p[restore[1]] = sys_ni_syscall_a;
	write_cr0(cr0);
	printk("%s: sys-call table restored to its original content\n",MODNAME);
	
}

