#include <stdio.h>

int main (int a, char** b){

	char buff[64];

	while(1){
		read(0,buff,64);
	}

	return 0;
}
