#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/errno.h>
#include <linux/device.h>
#include <linux/kprobes.h>
#include <linux/mutex.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/string.h>
#include <linux/vmalloc.h>
#include <linux/kthread.h>
#include <asm/page.h>
#include <asm/cacheflush.h>
#include <asm/apic.h>


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia <quaglia@dis.uniroma1.it>");
MODULE_DESCRIPTION("simply exposes a kernel level function pointer");

#define MODNAME "FUNCTION POINTER EXPOSER"

//extern unsigned long  * the_hook;
unsigned long the_hook;
module_param(the_hook,ulong,0777);

ulong i=0;

void f(void){
	if(current->pid == 0){
		printk("thread id %d found on CPU %d - TCB is located at address %p\n",current->pid,smp_processor_id(),current);
	}

	atomic_inc((atomic_t*)&i);

	if(i>100){
		printk("%s: function actually called\n",MODNAME);
		i=0;
	}
}



int init_module(void) {

	int ret;

	the_hook = (unsigned long)f;

	ret = 0;

	printk("%s: module mounted\n",MODNAME);

	return ret;
}


void cleanup_module(void) {

	printk("%s: module unmounted\n",MODNAME);
	
}

