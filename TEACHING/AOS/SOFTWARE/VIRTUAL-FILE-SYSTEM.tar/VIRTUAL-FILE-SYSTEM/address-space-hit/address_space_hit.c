
/*  
 *  address space hit dev file driver - you can update memory location of target processes by writing to this dev s 
 *  preliminary you need to mknod the dev file and assign the major retrived while mounting this module
 */

#define EXPORT_SYMTAB
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/sched.h>	
#include <linux/pid.h>		/* For pid types */
#include <linux/tty.h>		/* For the tty declarations */
#include <linux/version.h>	/* For LINUX_VERSION_CODE */


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia");



static int hit_open(struct inode *, struct file *);
static int hit_release(struct inode *, struct file *);
static ssize_t hit_write(struct file *, const char *, size_t, loff_t *);

#define DEVICE_NAME "hit"  /* Device file name in /dev/ - not mandatory  */


static int Major;            /* Major number assigned to broadcast device driver */

/* auxiliary stuff */
static inline void _write_cr3(unsigned long val)
{
          asm volatile("mov %0,%%cr3": : "r" (val), "m" (__force_order));
}


/* the actual driver */


static int hit_open(struct inode *inode, struct file *file)
{

//device opened by a default nop
   return 0;
}


static int hit_release(struct inode *inode, struct file *file)
{

//device closed by default nop
   return 0;

}

#define LINE_SIZE 128

static ssize_t hit_write(struct file *filp,
   const char *buff,
   size_t len,
   loff_t *off)
{
   char buffer[LINE_SIZE];
   long pid;
   unsigned long addr;
   long val;
   int format = 0;
   int i,j;
   int ret;

   char* args[3];

   struct task_struct *the_task;
   void** restore_pml4;
   unsigned long restore_cr3;
   struct mm_struct *restore_mm;



   printk("%s: somebody called a write on hit dev with [major,minor] number [%d,%d]\n",DEVICE_NAME,MAJOR(filp->f_dentry->d_inode->i_rdev),MINOR(filp->f_dentry->d_inode->i_rdev));
 
  if(len >= LINE_SIZE) return -1;
  ret = copy_from_user(buffer,buff,len);

  j = 1;
  for(i=0;i<len;i++){
	if(buffer[i] == ' ') {
		buffer[i] = '\0';
		args[j++] = buffer + i + 1;
		format++;
	}
  }

  if(format != 2) return -1;

  args[0] = buffer;

  buffer[len] = '\0';
  ret = kstrtol(args[0],10,&pid);
  ret = kstrtol(args[1],10,&addr);
  ret = kstrtol(args[2],10,&val);

  printk("%s: args are: %ld - %lu - %ld\n",DEVICE_NAME,pid,addr,val);


  the_task = pid_task(find_vpid(pid),PIDTYPE_PID);

  if(!the_task) return -1;

  restore_pml4 = (unsigned long)current->mm->pgd;
  restore_mm = (unsigned long)current->mm;
  restore_cr3 = read_cr3();

  if(!(the_task->mm)) return -1; 
  if(!(the_task->mm->pgd)) return -1; 

  printk("%s: process %ld is there with its memory map\n",DEVICE_NAME,pid);

  current->mm->pgd = the_task->mm->pgd;
  current->mm = the_task->mm;//this is needed to correctly handle empty zero memory 
  _write_cr3(__pa(the_task->mm->pgd));
  
  //do the hack
  ret = copy_to_user((void*)addr,(void*)&val,sizeof(val));

  //resume my own face
  current->mm = restore_mm;
  current->mm->pgd = restore_pml4;
  _write_cr3(restore_cr3);
   
  return len;
}



static struct file_operations fops = {
  .write = hit_write,
  .open =  hit_open,
  .release = hit_release
};



int init_module(void)
{

	Major = register_chrdev(0, DEVICE_NAME, &fops);

	if (Major < 0) {
	  printk("Registering hit device failed\n");
	  return Major;
	}

	printk(KERN_INFO "Hit device registered, it is assigned major number %d\n", Major);


	return 0;
}

void cleanup_module(void)
{

	unregister_chrdev(Major, DEVICE_NAME);

	printk(KERN_INFO "Hit device unregistered, it was assigned major number %d\n", Major);
}
