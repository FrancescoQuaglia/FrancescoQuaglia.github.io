
/*  
 *  address space hit dev file driver - you can update memory location of target processes by writing to this dev s 
 *  preliminary you need to mknod the dev file and assign the major retrived while mounting this module
 */

#define EXPORT_SYMTAB
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/sched.h>	
#include <linux/pid.h>		/* For pid types */
#include <linux/tty.h>		/* For the tty declarations */
#include <linux/version.h>	/* For LINUX_VERSION_CODE */


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia");

#define AUDIT if(1)

static int hit_open(struct inode *, struct file *);
static int hit_release(struct inode *, struct file *);
static ssize_t hit_write(struct file *, const char *, size_t, loff_t *);
static ssize_t hit_read(struct file *, const char *, size_t, loff_t *);

#define DEVICE_NAME "hit"  /* Device file name in /dev/ - not mandatory  */


static int Major;            /* Major number assigned to broadcast device driver */

/* auxiliary stuff */
static inline void _write_cr3(unsigned long val)
{
          asm volatile("mov %0,%%cr3": : "r" (val), "m" (__force_order));
}


/* the actual driver */


static int hit_open(struct inode *inode, struct file *file)
{

//device opened by a default nop
   return 0;
}


static int hit_release(struct inode *inode, struct file *file)
{

//device closed by default nop
   return 0;

}

#define LINE_SIZE 128

//#define PAGE_SIZE 4096

#define NO (0)
#define YES (NO+1)

char the_page[PAGE_SIZE];
int valid = 0;

#define PML4(addr) (((long long)(addr) >> 39) & 0x1ff)
#define PDP(addr) (((long long)(addr) >> 30) & 0x1ff)
#define PDE(addr) (((long long)(addr) >> 21) & 0x1ff)
#define PTE(addr) (((long long)(addr) >> 12) & 0x1ff)

static ssize_t hit_read(struct file *filp, const char *buff, size_t len, loff_t *off) {

	int ret;

	if (*off >= PAGE_SIZE || valid == NO) return 0;
	if (len > PAGE_SIZE - *off) len = PAGE_SIZE - *off;

	//copy to user the logged page
	ret = copy_to_user((void*)buff,(void*)the_page,len);

	*off = len - ret;
	return len - ret;

}

static ssize_t hit_write(struct file *filp, const char *buff, size_t len, loff_t *off) {

   char buffer[LINE_SIZE];
   long pid;
   unsigned long addr;
   long val;
   int format = 0;
   int i,j;
   int ret;

   char* args[3];

   char* target_page;

   struct task_struct *the_task;
   void** restore_pml4;
   unsigned long restore_cr3;
   struct mm_struct *restore_mm;

   void ** my_pdp;
   void ** my_pd;
   void ** my_pde;
   void ** my_pte;


   printk("%s: somebody called a read on hit dev with [major,minor] number [%d,%d]\n",DEVICE_NAME,MAJOR(filp->f_dentry->d_inode->i_rdev),MINOR(filp->f_dentry->d_inode->i_rdev));
 
  if(len >= LINE_SIZE) return -1;
  ret = copy_from_user((void*)buffer,(void*)buff,len);

  j = 1;
  for(i=0;i<len;i++){
	if(buffer[i] == ' ') {
		buffer[i] = '\0';
		args[j++] = buffer + i + 1;
		format++;
	}
  }

  if(format != 1) return -1;

  args[0] = buffer;

  buffer[len] = '\0';
  ret = kstrtol(args[0],10,&pid);
  ret = kstrtol(args[1],10,&addr);
 // ret = kstrtol(args[2],10,&val);

  printk("%s: args are: %ld - %lu - %ld\n",DEVICE_NAME,pid,addr,val);

  the_task = pid_task(find_vpid(pid),PIDTYPE_PID);

  if(!the_task) return -1;

  restore_pml4 = (unsigned long)current->mm->pgd;
  restore_mm = (unsigned long)current->mm;
  restore_cr3 = read_cr3();

  if(!(the_task->mm)){
	ret = -1; 
	goto out;
  }
  atomic_inc(&(the_task->mm->mm_count));//to be released in failures of below parts

  if(!(the_task->mm->pgd)){ 
	ret = -1; 
	goto mm_release;
  }
  spin_lock(&(the_task->mm->page_table_lock));//to be released in failures of below parts

  AUDIT
  printk("%s: process %ld is there with its memory map\n",DEVICE_NAME,pid);

  current->mm->pgd = the_task->mm->pgd;
  current->mm = the_task->mm;//this is needed to correctly handle empty zero memory 
  _write_cr3(__pa(the_task->mm->pgd));

  my_pdp = the_task->mm->pgd;

  if((ulong)my_pdp[PML4(addr)] & 0x1){
  	printk("%s: process %ld has PML4 mapped page at address %p\n",DEVICE_NAME,pid,addr);

	my_pd = __va((ulong)my_pdp[PML4(addr)] & 0x7ffffffffffff000);

	if((ulong)my_pd[PDP(addr)] & 0x1){
  		printk("%s: process %ld has PDP mapped page at address %p\n",DEVICE_NAME,pid,addr);
		my_pde = __va((ulong)my_pd[(ulong)PDP(addr)] & 0x7ffffffffffff000);

		if((ulong)my_pde[PDE(addr)] & 0x1){
  			printk("%s: process %ld has PDE mapped page at address %p\n",DEVICE_NAME,pid,addr);
			my_pte = __va((ulong)my_pde[PDE(addr)]& 0x7ffffffffffff000);

			if((ulong)my_pte[PTE(addr)] & 0x1){
  				printk("%s: process %ld has PTE mapped page at address %p\n",DEVICE_NAME,pid,addr);
				target_page =(char*)__va((ulong)my_pte[PTE(addr)]& 0x7ffffffffffff000);
				memcpy((char*)the_page,(char*)target_page,PAGE_SIZE);
				valid = YES;
				goto copy_done;
			}
		}
       }
  }

  AUDIT
  printk("%s: process %ld has no mapped page at address %p\n",DEVICE_NAME,pid,addr);

copy_done:
  
  //do the hack
 // ret = copy_to_user((void*)addr,(void*)&val,sizeof(val));

  //resume my own face
  current->mm = restore_mm;
  current->mm->pgd = restore_pml4;
  _write_cr3(restore_cr3);

  spin_unlock(&(the_task->mm->page_table_lock));//to be released in failures of below parts

mm_release:
  atomic_dec(&(the_task->mm->mm_count));//to be released in failures of below parts

out:
  return len;

}


static struct file_operations fops = {
  .owner = THIS_MODULE,
  .write = hit_write,
  .read = hit_read,
  .open =  hit_open,
  .release = hit_release
};


int init_module(void) {

	Major = register_chrdev(0, DEVICE_NAME, &fops);

	if (Major < 0) {
	  printk("Registering hit device failed\n");
	  return Major;
	}

	printk(KERN_INFO "Hit device registered, it is assigned major number %d\n", Major);


	return 0;
}

void cleanup_module(void) {

	unregister_chrdev(Major, DEVICE_NAME);

	printk(KERN_INFO "Hit device unregistered, it was assigned major number %d\n", Major);
}
