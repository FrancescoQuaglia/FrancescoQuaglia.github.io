#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <pthread.h>

#ifndef PERIOD
#define PERIOD 1
#endif

#define  AUDIT if(0)

#ifndef LOCK
#define list_insert rcu_list_insert
#define list_search rcu_list_search
#define list_remove rcu_list_remove
#define list_init rcu_list_init
#endif

typedef struct _element{
	struct _element * next;
	long key;
} element;

typedef struct _rcu_list{
	int epoch;
	long standing[2];
	pthread_spinlock_t write_lock;
	element * head;
} rcu_list;


void rcu_list_init(rcu_list * l);

int rcu_list_search(rcu_list *l, long key);

int rcu_list_insert(rcu_list *l, long key);

int rcu_list_remove(rcu_list *l, long key);
