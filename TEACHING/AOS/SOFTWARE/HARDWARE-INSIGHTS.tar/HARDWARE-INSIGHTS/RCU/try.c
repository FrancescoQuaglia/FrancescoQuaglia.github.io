#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <pthread.h>
#include "rcu-list.h"

#ifndef THREADS
#define THREADS (16)
#endif


rcu_list the_list;


void worker(void* id){
	int j;

	if ((long)id == 0){
		for (j= 0; j<100 ; j++)	{
			printf("thread %d - inserting key %d - result %d\n",(long)id,j,list_insert(&the_list,j));
		}	
		printf("thread %d - insertions done\n",(long)id);
		return;
	}
	if ((long)id == 1){
		sleep(1);
		for (j= 0; j<100 ; j++)	{
			printf("thread %d - removing key %d - result %d\n",(long)id,j,list_remove(&the_list,j));
		}	
		printf("thread %d - removals done\n",(long)id);
		return;
	}
	
	sleep(1);
	printf("thread %d - scanning the list for key %d - result %d\n",(long)id,(long)id,list_search(&the_list,(long)id));

}

int main(int argc, char* argv){

	unsigned long i;
	pthread_t tid;

	list_init(&the_list);


	for(i=0; i<THREADS; i++){

		pthread_create(&tid,NULL,worker,(void*)i);

	}

	pause();
}
