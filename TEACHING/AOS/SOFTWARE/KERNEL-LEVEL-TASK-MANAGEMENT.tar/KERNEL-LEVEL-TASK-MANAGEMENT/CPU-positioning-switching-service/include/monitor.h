#ifndef LOG_STRUCTURE
#define LOG_STRUCTURE

typedef struct _monitor {
        int cpu_id;
	int switches;
} monitor;

#endif

