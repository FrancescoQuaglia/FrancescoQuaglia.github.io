#ifndef _CONTROL_H
#define _CONTROL_H

//int setup_my_irq(void (*hop_handler) (void));
int setup_my_irq(void);

void cleanup_my_irq(void);


#endif /* IBS_CONTROL_H */
