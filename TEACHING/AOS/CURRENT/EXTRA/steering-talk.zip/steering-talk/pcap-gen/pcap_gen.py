#!/usr/bin/env python3

from scapy.all import Ether, RandMAC, RandIP, IP, UDP, wrpcap

base = Ether(src=RandMAC(), dst=RandMAC())

# NOTE: you could need to re-generate the PCAP few times in order to find
# two flows that will go in different buckets.
# Obviously you can increase the sockets in the group in order to increase
# the probability of the "happy-scenario"
alpha = str(RandIP())
bravo = str(RandIP())
charlie = str(RandIP())
delta = str(RandIP())

udp = UDP(sport=49152, dport=49153)

pkts = []
pkts.append(base / IP(src=alpha, dst=bravo) / udp / "Hi I'm Alpha")
pkts.append(base / IP(src=bravo, dst=alpha) / udp / "Hi I'm Bravo")
pkts.append(base / IP(src=charlie, dst=delta) / udp / "Hi I'm Charlie")
pkts.append(base / IP(src=delta, dst=charlie) / udp / "Hi I'm Delta")

wrpcap("example.pcap", pkts)
