#set document(
  title: "Introduzione allo steering",
  author: "Simone Tiberi",
  date: datetime(year: 2026, month: 3, day: 26),
)
#show link: set text(fill: blue)
#show link: underline

#title()

= Struttura
```
.
|-- client
|   |-- main.c
|   `-- Makefile
|-- Justfile
|-- pcap-gen
|   |-- pcap_gen.py
|   `-- requirements.txt
|-- README.typ
`-- slides
    |-- steering-p1.pdf
    |-- steering-p2.pdf
    `-- steering-p4.pdf
```

== README
Questo documento può essere consultato _as is_ oppure, può essere compilato
nella sua versione `PDF` sfruttando il comando:
```
$ typst compile
```

== Client
Nella cartella `client` è presente il sorgente C dell'analizzatore mostrato
durante il talk. Per compilarlo è sufficiente eseguire il comando:
```
$ make
```

Qualora il vostro terminale *non* supporti caratteri unicode è possibile
disabilitarli rimuovendo il flag `-DUNICODE` dai `CFLAGS` presenti nel Makefile

== PCAP generator
Nella cartella `pcap-gen` è presente lo script python mostrato durante il talk
necessario per generare la PCAP in grado di stimolare gli scenari di interesse.

All'interno della directory è presente il file `requirements.txt` al fine di
facilitare il setup di un virtual environment in cui eseguire lo script.

Una volta generata la PCAP, è possibile _inoltrarla_ sull'interfaccia target
sfruttando il tool `tcpreplay`, ad esempio eseguendo:

```
# tcpreplay tcpreplay -i tom -- example.pcap
```

== Slides
Le slide mostrate durante il talk sono riportate all'interno della cartella
`slides` in diversi formati (i.e., 1 slide per pagina, 2 slide per pagina, 4
slide per pagina).

== Setup ambientale
Il setup ambientale, volto all'esecuzione del running example mostrato durante
il talk, è automatizzato attraverso il
`Justfile`#footnote[#link("https://just.systems/man/en/")[`just`] è una
_moderna_ alternativa a `make`.] presente nella root della directory.


