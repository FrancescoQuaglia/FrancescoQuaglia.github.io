
#ifndef _SCTH_

#define _SCTH_

void begin_syscall_table_hack(void);
void end_syscall_table_hack(void);
int get_entries(int *, int, unsigned long, unsigned long* );

#endif
