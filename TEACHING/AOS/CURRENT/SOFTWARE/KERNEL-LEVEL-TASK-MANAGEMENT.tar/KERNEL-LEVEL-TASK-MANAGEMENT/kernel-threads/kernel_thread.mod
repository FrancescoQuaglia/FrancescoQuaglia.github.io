./kernel_thread.o
