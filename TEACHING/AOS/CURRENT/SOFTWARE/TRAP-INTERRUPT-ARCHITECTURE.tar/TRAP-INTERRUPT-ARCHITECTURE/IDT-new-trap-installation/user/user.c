
int main(){
	asm ("int $0xff"::);
}
