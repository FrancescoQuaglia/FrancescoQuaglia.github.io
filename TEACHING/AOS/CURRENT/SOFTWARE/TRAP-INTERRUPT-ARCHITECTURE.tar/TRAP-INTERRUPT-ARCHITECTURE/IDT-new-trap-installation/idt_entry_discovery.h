#ifndef _CONTROL_H
#define _CONTROL_H

#define MOD_NAME "IDT ENTRY DISCOVERY"


int idt_entry_discovery_init(void);
void idt_entry_discovery_exit(void);

#endif 
