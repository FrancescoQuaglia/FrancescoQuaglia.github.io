
#ifndef _SCTH_

#define _SCTH_

void unprotect_memory(void);
void protect_memory(void);
int get_entries(int *, int, unsigned long, unsigned long* );

#endif
