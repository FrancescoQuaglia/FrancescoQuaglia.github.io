
#ifndef _SCTH_

#define _SCTH_

void protect_memory(void);
void unprotect_memory(void);
int get_entries(int *, int, unsigned long*, unsigned long* );

#endif
