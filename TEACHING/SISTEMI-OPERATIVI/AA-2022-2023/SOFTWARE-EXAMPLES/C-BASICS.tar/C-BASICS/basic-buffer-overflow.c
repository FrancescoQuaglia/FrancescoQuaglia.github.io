
#include <stdio.h>

long control_variable;
long v[10];

int main(int argc, char * argv[]){

	long index, value;


#ifdef INSTACK
	long control_variable;
	long v[10];
#endif

	control_variable = 1;

	while (control_variable == 1){
		scanf("%ld%ld",&index,&value);
		v[index] = value;
		printf("array elem at position %ld has been set to value %ld\n",index,v[index]);


	}

	printf("exited cycle\n");

	return 0;
}

