
#define VALUE 20

int functionB(int x){

	return x%VALUE;

}
