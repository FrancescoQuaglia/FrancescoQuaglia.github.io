#define _REENTRANT
#include <stdio.h>
#include <pthread.h>
#include <signal.h>

char v[1024];


void generic_handler(int signal){

	printf("received signal is %d\n",signal);
}



int main(int argc, char **argv){

  int  i;
  sigset_t set;


  sigfillset(&set);
  sigprocmask(SIG_BLOCK,&set,NULL);

  while(1) {
	sleep(3);
	printf("quering the sigset\n");
	sigpending(&set);
	if(sigismember(&set,SIGINT)){
	  sigemptyset(&set);
	  sigaddset(&set,SIGINT);
	  sigprocmask(SIG_UNBLOCK,&set,NULL);
	}
  }

}
