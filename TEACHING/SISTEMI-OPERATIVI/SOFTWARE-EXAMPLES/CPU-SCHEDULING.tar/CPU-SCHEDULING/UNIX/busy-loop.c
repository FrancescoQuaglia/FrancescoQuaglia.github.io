void __start(){
	while(1);
}
