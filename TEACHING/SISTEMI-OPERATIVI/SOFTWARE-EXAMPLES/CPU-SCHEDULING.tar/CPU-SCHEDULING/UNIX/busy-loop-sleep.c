#include <unistd.h>

void __start(){
	while(1) sleep(1);
}
