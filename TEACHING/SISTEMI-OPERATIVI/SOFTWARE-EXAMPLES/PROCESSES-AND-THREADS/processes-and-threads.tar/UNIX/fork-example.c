#include<stdio.h>
#include<stdlib.h>

int main(int a, char **b){
	
 	pid_t pid;

	pid = fork();

	if (pid == 0){

		printf("child process simply exiting\n");
		pid = fork();
		exit(0);
	}

	printf("parent process simply goes pausing\n");
	pause();

}
