
//please compile with -nostartfiles

#include <stdio.h>
#include <stdlib.h>


_start(){

	printf("hello world!\n");
	exit(0);//beware removing this!!

}
