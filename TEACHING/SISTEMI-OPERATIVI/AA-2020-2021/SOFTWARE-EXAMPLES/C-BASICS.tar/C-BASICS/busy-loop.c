
//please compile with -nostartfiles


int f(){
 while(1){
 }
}

