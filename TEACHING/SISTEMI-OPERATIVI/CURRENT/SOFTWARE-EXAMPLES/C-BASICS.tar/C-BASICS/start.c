
//please compile with -nostartfiles

#include <stdio.h>
#include <stdlib.h>


void _start(void){

	printf("hello world!\n");
	exit(0);//beware removing this!!

}
