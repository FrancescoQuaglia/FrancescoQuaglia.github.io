
#define VALUE 10

int functionA(int x){

	return x%VALUE;

}
