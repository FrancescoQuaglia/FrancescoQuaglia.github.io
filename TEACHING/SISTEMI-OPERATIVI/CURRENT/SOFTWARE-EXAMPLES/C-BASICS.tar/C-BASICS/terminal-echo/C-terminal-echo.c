#include <stdio.h>

int main(int x, char** y){
	char c;

	while(1){
		scanf("%c",&c);
		printf("%c",c);

	}
}
