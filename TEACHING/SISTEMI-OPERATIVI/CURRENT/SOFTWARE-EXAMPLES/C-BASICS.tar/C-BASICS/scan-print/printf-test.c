#include <stdio.h>

char* text = "francesco";
 
int main(int a, char** b){

	printf("\n%d\n",printf("%s",text));
	printf("%s\n",text);
}
