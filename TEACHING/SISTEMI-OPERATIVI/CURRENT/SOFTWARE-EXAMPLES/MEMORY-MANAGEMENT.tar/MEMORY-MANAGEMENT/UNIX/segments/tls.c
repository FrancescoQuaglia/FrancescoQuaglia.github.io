
__thread int x;

__start(){

	x = 4;

}

