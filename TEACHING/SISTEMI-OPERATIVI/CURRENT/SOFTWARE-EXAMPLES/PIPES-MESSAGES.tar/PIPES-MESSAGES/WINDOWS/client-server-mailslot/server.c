/*********************************************************/
/*************** server process **************************/
/*********************************************************/

#include <windows.h>
#include <stdio.h>
#include <malloc.h>

#include "header.h"

HANDLE id_coda;
int ret, STATUS;
char *response = (char*)"done";

DWORD WINAPI service_thread(request_msg *request_message) {
	response_msg response_message;
	HANDLE response_queue_id;
	DWORD writtenchars;

	printf("asked service of type %d - response channel is %s\n", request_message->req.service_code, request_message->req.queue_name);
	fflush(stdout);

	/* do the service */
	Sleep(5000);//simulate a delay for service processing

	response_queue_id = CreateFileA(
		request_message->req.queue_name,
		GENERIC_WRITE,
		FILE_SHARE_READ,  // required to write to a mailslot
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if (response_queue_id == INVALID_HANDLE_VALUE) {
		printf("cannot open response queue to the client\n");
		ExitThread(FAILURE);
	}

	memcpy(response_message.mtext, response, strlen(response)+1);
	if (WriteFile(response_queue_id, &response_message,
		SIZE, &writtenchars, NULL) == 0) {
		printf("cannot return response to the client\n");
		ExitThread(FAILURE);
	}

	free(request_message);
	return 0;
}

int main(int argc, char *argv[]) {

	void * request_message;
	DWORD thread_id;
	DWORD readchar;

	id_coda = CreateMailslotA(
		"\\\\.\\mailslot\\server",
		sizeof(request_msg),
		MAILSLOT_WAIT_FOREVER,
		NULL);

	if (id_coda == INVALID_HANDLE_VALUE) {
		printf("cannot install server queue, please check the problem\n");
		return FAILURE;
	}

	while (1) {
		request_message = malloc(sizeof(request_msg));
		if (ReadFile(id_coda, request_message, sizeof(request_msg), &readchar, NULL) == 0) {
			printf("message receive error, please check the problem\n");
			ExitProcess(FAILURE);
		}
		else {

#ifdef MULTITHREAD
			if (CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)service_thread, request_message, 0, &thread_id)
				== INVALID_HANDLE_VALUE) {
				printf("Cannot create service thread for error %d\n", GetLastError());
				ExitProcess(FAILURE);
			}

#endif

#ifndef MULTITHREAD
			service_thread((request_msg*)request_message);
#endif

		}
	}/* end while */
}/* end main*/


