/*********************************************************/
/*************** client process **************************/
/*********************************************************/

#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>

#include "header.h"

HANDLE my_id_coda, id_coda;
int ret, STATUS;
long key;

char queue_name[MAX_NAME_SIZE];
request_msg  request_message;
response_msg response_message;


int main(int argc, char *argv[]) {

	DWORD writtenchars, readchars;
	int aux;

	key = GetCurrentProcessId();

	sprintf(queue_name, "\\\\.\\mailslot\\client%d", key);
	my_id_coda = CreateMailslotA(
		queue_name,
		sizeof(response_msg),
		MAILSLOT_WAIT_FOREVER,
		NULL);


	if (my_id_coda == INVALID_HANDLE_VALUE) {
		printf("cannot install client queue, please check with the problem\n");
		fflush(stdout);
		ExitProcess(FAILURE);
	}

	printf("client %d - mail slot created\n",key);

	id_coda = CreateFileA(
		"\\\\.\\mailslot\\server",
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,  // required to write to a mailslot
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	if (id_coda == INVALID_HANDLE_VALUE) {
		printf("cannot open server queue, please check with the problem\n");
		ExitProcess(FAILURE);
	}

	printf("client %d - server mail slot opened\n",key);

	request_message.req.service_code = 1;
	strcpy(request_message.req.queue_name, queue_name);

	if (WriteFile(id_coda, &request_message,
		sizeof(request), &writtenchars, NULL) == 0) {
		printf("client %d - cannot send request to the server\n",key);
		fflush(stdout);
		ExitProcess(FAILURE);
	}

	printf("client %d - request message sent to server\n",key);
	fflush(stdout);

	if (ReadFile(my_id_coda, &response_message, SIZE, &readchars, NULL) == 0) {
		printf("error while receiving the server response, please check with the problem\n");
		fflush(stdout);
		ExitProcess(FAILURE);
	}
	else {
		printf("client %d - server response: %s\n", key,response_message.mtext);
		fflush(stdout);
		ExitProcess(0);
	}

}/* end main*/

