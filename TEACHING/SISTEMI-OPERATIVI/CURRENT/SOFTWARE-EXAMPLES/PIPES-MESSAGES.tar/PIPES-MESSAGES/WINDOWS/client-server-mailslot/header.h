
#ifndef _HEADER
#define _HEADER

#define FAILURE        1
#define SIZE        128
#define MAX_NAME_SIZE 128

#define MULTITHREAD


typedef struct {
        char queue_name[MAX_NAME_SIZE];
        int service_code;
} request;


typedef struct {
        request req;
} request_msg;


typedef struct {
        char mtext[SIZE];
} response_msg;

#endif
