#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int a, char **b){
	
 	pid_t pid;
	int exit_code;

	pid = fork();

	if (pid == 0){
	redo:
		printf("\nchild process querying parent id is %d\n",getppid());
		if (getppid()==1){
		       printf("now my parent is systemd - I'm exiting\n");
	       	       exit(0);
		}
		printf("going to sleep\n");
		fflush(stdout);
		sleep(3);
		goto redo;
	}

	sleep(1);
	exit(0);

}
