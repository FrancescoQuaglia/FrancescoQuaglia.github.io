

#define BUFSIZE 1024
#define MAX_FILE_NAME_LENGTH 128

typedef struct _file_info{
        char file_name[MAX_FILE_NAME_LENGTH];
        int  start_position;
        int  end_position;
} file_info;

typedef struct _header{
        int  num_files;
	file_info *the_files;
} header;


#define AUDIT if(0)
