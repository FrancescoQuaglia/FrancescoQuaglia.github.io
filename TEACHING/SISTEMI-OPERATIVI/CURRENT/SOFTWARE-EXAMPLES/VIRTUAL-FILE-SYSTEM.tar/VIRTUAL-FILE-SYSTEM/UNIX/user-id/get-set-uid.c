#include <unistd.h>
#include <stdio.h>

int main(int a ,char** b){

	uid_t id, eid;

	id = getuid();
	eid = geteuid();
	printf("I'm running on behalf of user %d - effective %d\n",(int)id, (int)eid);
	printf(".. who would you like to become? ");
	scanf("%d",&id);
	setuid(id);
	id = getuid();
	printf("I'm now running on behalf of user %d\n",(int)id);
	pause();

}
