#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

#define BUFSIZE 1024

int main(int argc, char *argv[]) { 
	int des; 

	 if (argc != 2) { /* check the number of arguments */ 

		printf("usage: creat file-name\n");
		exit(EXIT_FAILURE);
	 }  

	des = creat(argv[1],0660);
	/* FROM THE MAN PAGE -> The effective mode is modified by the process's umask in the usual
              way: in the absence of a default  ACL,  the  mode  of  the  created  file  is
              (mode & ~umask) */

	printf("file creation returned with descriptor %d\n",des);

  }/* end main*/

