#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
        execlp("ls","ls",0);
        printf("La chiamata execlp() ha fallito\n");
}
